Narrator Off (Forge 1.20.1, client side)
=======================================

What it does
- Keeps the narrator set to OFF. If anything turns it on (including the Ctrl+B shortcut), the mod sets it back to OFF within a tick.
- Client only. It does nothing on a dedicated server, so only put the finished jar in the client pack.
- It replaces Rebind Narrator in the pack. Remove that jar when you add this one.

How to build it (no command line needed)
1. Install a Java 17 JDK (for example Eclipse Temurin 17) and the free IntelliJ IDEA Community Edition.
2. Unzip this project into a folder with a short path that has no spaces, for example a new folder on your Desktop called narrator-off (create it first).
3. In IntelliJ, choose Open and pick that folder. When it asks, trust the project and let it import as a Gradle project. The first import downloads Minecraft and Forge and takes several minutes.
4. In the Gradle panel on the right, open Tasks, then build, then double-click "build".
5. The finished mod is in the build/libs folder and is named narratoroff-1.0.0.jar.
6. Copy that jar into the client pack's mods folder.

Source
- src/main/java/dev/kit/narratoroff/NarratorOff.java holds all the logic.
- This project has not been compiled yet, so a compile error is possible. If the build fails, send the error text back and it will be fixed.
